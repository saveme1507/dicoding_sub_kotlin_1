package id.tangerang.submision_1.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "db_favorite"
        private const val DATABASE_VERSION = 1
        private const val SQL_CREATE_TABLE_FAVORITE =
            "CREATE TABLE ${UserFavoriteContract.UserFavoriteColumns.TABLE_NAME}" +
                    " (${UserFavoriteContract.UserFavoriteColumns.ID} INTEGER PRIMARY KEY AUTOINCREMENT," +
                    " ${UserFavoriteContract.UserFavoriteColumns.USERNAME} TEXT NOT NULL," +
                    " ${UserFavoriteContract.UserFavoriteColumns.NAME} TEXT NOT NULL," +
                    " ${UserFavoriteContract.UserFavoriteColumns.AVATAR} TEXT NOT NULL," +
                    " ${UserFavoriteContract.UserFavoriteColumns.COMPANY} TEXT NOT NULL," +
                    " ${UserFavoriteContract.UserFavoriteColumns.LOCATION} TEXT NOT NULL," +
                    " ${UserFavoriteContract.UserFavoriteColumns.REPOSITORY} TEXT NOT NULL," +
                    " ${UserFavoriteContract.UserFavoriteColumns.FOLLOWERS} TEXT NOT NULL," +
                    " ${UserFavoriteContract.UserFavoriteColumns.FOLLOWING} TEXT NOT NULL,"+
                    " ${UserFavoriteContract.UserFavoriteColumns.CREATED_AT} DATETIME NOT NULL,"+
                    " ${UserFavoriteContract.UserFavoriteColumns.UPDATED_AT} DATETIME)"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_TABLE_FAVORITE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS ${UserFavoriteContract.UserFavoriteColumns.TABLE_NAME}")
        onCreate(db)
    }
}