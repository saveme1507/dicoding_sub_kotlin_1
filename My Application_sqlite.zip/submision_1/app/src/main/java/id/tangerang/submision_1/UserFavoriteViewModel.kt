package id.tangerang.submision_1

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import id.tangerang.submision_1.db.UserFavoriteContract
import id.tangerang.submision_1.db.UserFavoriteHelper
import id.tangerang.submision_1.models.UserModel

class UserFavoriteViewModel(application: Application) : AndroidViewModel(application) {
    private var userFavoriteHelper: UserFavoriteHelper =
        UserFavoriteHelper(application.applicationContext)
    private var usersFavorite: MutableLiveData<MutableList<UserModel>> =
        MutableLiveData<MutableList<UserModel>>()

    fun getUsers(): LiveData<MutableList<UserModel>> {
        return usersFavorite
    }

    fun loadUsers() {
        userFavoriteHelper.open()
        val cursor = userFavoriteHelper.queryAll()

        val users = mutableListOf<UserModel>()
        for (i in 0 until cursor.count) {
            cursor.moveToPosition(i)
            users.add(
                UserModel(
                    cursor.getString(cursor.getColumnIndex(UserFavoriteContract.UserFavoriteColumns.USERNAME)),
                    cursor.getString(cursor.getColumnIndex(UserFavoriteContract.UserFavoriteColumns.NAME)),
                    cursor.getString(cursor.getColumnIndex(UserFavoriteContract.UserFavoriteColumns.AVATAR)),
                )
            )
        }
        usersFavorite.postValue(users)
        userFavoriteHelper.close()
    }

}