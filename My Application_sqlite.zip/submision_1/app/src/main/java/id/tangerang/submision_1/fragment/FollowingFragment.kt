package id.tangerang.submision_1.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import id.tangerang.submision_1.USERNAME
import id.tangerang.submision_1.databinding.FollowingFragmentBinding
import id.tangerang.submision_1.utils.ApiRequest
import id.tangerang.submision_1.adapters.UserAdapter
import id.tangerang.submision_1.models.UserModel

class FollowingFragment : Fragment() {
    private lateinit var binding: FollowingFragmentBinding
    private lateinit var userAdapter: UserAdapter
    private var users: MutableList<UserModel> = mutableListOf()
    private lateinit var viewModel: FollowingViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FollowingFragmentBinding.inflate(layoutInflater, container, false)

        userAdapter = UserAdapter(requireContext(), users)
        binding.rvList.adapter = userAdapter
        binding.rvList.layoutManager = LinearLayoutManager(context)

        userAdapter.setOnClickItem(object : UserAdapter.IOnClickItem{
            override fun onClick(position: Int) {

            }
        })

        viewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory(requireActivity().application)).get(FollowingViewModel::class.java)
        viewModel.setApiRequest(ApiRequest(requireContext()))

        arguments?.getString(USERNAME)?.let { viewModel.loadUsers(it) }

        viewModel.getUsers().observe(requireActivity(), {
            users.clear()
            this.users.addAll(it)
            userAdapter.notifyDataSetChanged()
        })

        return binding.root
    }
}