package id.tangerang.submision_1

import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import id.tangerang.submision_1.adapters.UserAdapter
import id.tangerang.submision_1.databinding.ActivitySearchUsersBinding
import id.tangerang.submision_1.models.UserModel
import id.tangerang.submision_1.utils.ApiRequest

class UserFavoriteActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySearchUsersBinding
    private lateinit var apiRequest: ApiRequest
    private lateinit var userAdapter: UserAdapter
    private lateinit var model: UserFavoriteViewModel
    private var users: MutableList<UserModel> = mutableListOf()
    private val context = this@UserFavoriteActivity
    private var textQuery = ""

    @SuppressLint("NotifyDataSetChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchUsersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (supportActionBar != null) {
            title = getString(R.string.user_favorite)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        apiRequest = ApiRequest(context)

        userAdapter = UserAdapter(context, users)
        binding.rvList.adapter = userAdapter
        binding.rvList.layoutManager = LinearLayoutManager(context)

        userAdapter.setOnClickItem(object : UserAdapter.IOnClickItem {
            override fun onClick(position: Int) {
                startActivity(
                    Intent(context, DetailUserActivity::class.java)
                        .putExtra("username", users[position].name)
                )
            }
        })

        model = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory(this.application)
        ).get(UserFavoriteViewModel::class.java)

        model.loadUsers()
        model.getUsers().observe(this, { users ->
            this.users.clear()
            this.users.addAll(users)
            userAdapter.notifyDataSetChanged()

            if (binding.swipe.isRefreshing) binding.swipe.isRefreshing = false
        })

        binding.swipe.setOnRefreshListener {
            binding.swipe.isRefreshing = true
            model.loadUsers()
        }
    }

    override fun onRestart() {
        super.onRestart()
        model.loadUsers()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_option_2, menu)
        val searchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = getString(R.string.hint_search_users)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                userAdapter.filter(newText, users)
                return true
            }
        })

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }
            R.id.option_language -> {
                val mIntent = Intent(Settings.ACTION_LOCALE_SETTINGS)
                startActivity(mIntent)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}