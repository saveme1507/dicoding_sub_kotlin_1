package id.tangerang.submision_1

import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import id.tangerang.submision_1.databinding.ActivitySearchUsersBinding
import id.tangerang.submision_1.utils.ApiRequest
import id.tangerang.submision_1.adapters.UserAdapter
import id.tangerang.submision_1.models.UserModel
import java.util.*

class SearchUsersActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySearchUsersBinding
    private lateinit var apiRequest: ApiRequest
    private lateinit var userAdapter: UserAdapter
    private lateinit var model: SearchUsersViewModel
    private var users: MutableList<UserModel> = mutableListOf()
    private val context = this@SearchUsersActivity
    private var backPress = false
    private var textQuery = ""

    @SuppressLint("NotifyDataSetChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchUsersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (supportActionBar != null) {
            title = getString(R.string.title_search_activity)
        }

        apiRequest = ApiRequest(context)

        userAdapter = UserAdapter(context, users)
        binding.rvList.adapter = userAdapter
        binding.rvList.layoutManager = LinearLayoutManager(context)

        userAdapter.setOnClickItem(object : UserAdapter.IOnClickItem {
            override fun onClick(position: Int) {
                startActivity(
                    Intent(context, DetailUserActivity::class.java)
                        .putExtra("username", users[position].name)
                )
            }
        })

        model = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory(this.application)
        ).get(SearchUsersViewModel::class.java)

        model.setApiRequest(apiRequest)
        model.getUsers().observe(this, { users ->
            this.users.clear()
            this.users.addAll(users)
            userAdapter.notifyDataSetChanged()

            apiRequest.dismissProgressDialog()
            if (binding.swipe.isRefreshing) binding.swipe.isRefreshing = false
        })

        binding.swipe.setOnRefreshListener {
            if (textQuery.isBlank()) {
                binding.swipe.isRefreshing = false
            } else {
                model.loadUsers(textQuery)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_option, menu)
        val searchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = getString(R.string.hint_search_users)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                apiRequest.showProgressDialog()
                model.loadUsers(textQuery)
                return true
            }

            @SuppressLint("NotifyDataSetChanged")
            override fun onQueryTextChange(newText: String): Boolean {
                if (newText.isBlank()) {
                    users.clear()
                    userAdapter.notifyDataSetChanged()
                }
                textQuery = newText
                return true
            }
        })

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.option_language -> {
                val mIntent = Intent(Settings.ACTION_LOCALE_SETTINGS)
                startActivity(mIntent)
            }
            R.id.user_favorite -> {
                val mIntent = Intent(context, UserFavoriteActivity::class.java)
                startActivity(mIntent)
            }
        }
        return super.onOptionsItemSelected(item)
    }


    override fun onBackPressed() {
        if (backPress) {
            super.onBackPressed()
            return
        }

        this.backPress = true
        Toast.makeText(this, getString(R.string.msg_double_click_close), Toast.LENGTH_SHORT).show()
        Handler(Looper.getMainLooper()).postDelayed({ backPress = false }, 2000)
    }
}