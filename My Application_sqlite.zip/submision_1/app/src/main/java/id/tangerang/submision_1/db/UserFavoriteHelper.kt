package id.tangerang.submision_1.db

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.provider.BaseColumns._ID
import id.tangerang.submision_1.db.UserFavoriteContract.UserFavoriteColumns.Companion.TABLE_NAME
import id.tangerang.submision_1.entity.UserFavorite
import java.sql.SQLException

class UserFavoriteHelper(context: Context) {
    private var dataBaseHelper: DatabaseHelper = DatabaseHelper(context)
    private lateinit var database: SQLiteDatabase

    companion object {
        private const val DATABASE_TABLE = TABLE_NAME
        private var INSTANCE: UserFavoriteHelper? = null

        fun getInstance(context: Context): UserFavoriteHelper =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: UserFavoriteHelper(context)
            }
    }

    @Throws(SQLException::class)
    fun open() {
        database = dataBaseHelper.writableDatabase
    }

    fun close() {
        dataBaseHelper.close()

        if (database.isOpen)
            database.close()
    }

    fun queryAll(): Cursor {
        return database.query(
            DATABASE_TABLE,
            null,
            null,
            null,
            null,
            null,
            "$_ID ASC",
            null
        )
    }

    @SuppressLint("Recycle")
    fun queryById(username: String): MutableMap<String, String> {
        val cursor =
            database.rawQuery("SELECT * FROM $DATABASE_TABLE WHERE username=?", arrayOf(username))
        return if (cursor.moveToFirst()) {
            val columnNames = cursor.columnNames
            val map = mutableMapOf<String, String>()
            for (i in columnNames.indices) {
                map[columnNames[i].toString()] =
                    cursor.getString(cursor.getColumnIndex(columnNames[i].toString())) ?: "null";
            }
            return map
        } else {
            mutableMapOf()
        }
    }

    fun insert(values: ContentValues?): Long {
        return database.insert(DATABASE_TABLE, null, values)
    }

    fun update(id: String, values: ContentValues?): Int {
        return database.update(DATABASE_TABLE, values, "$_ID = ?", arrayOf(id))
    }

    fun deleteById(username: String): Int {
        return database.delete(DATABASE_TABLE, "username=?", arrayOf(username))
    }
}